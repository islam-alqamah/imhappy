# Release notes

---
This script will be updated regularily with latest version of framework & plugins. Please share your feedback, feature request which will be surely implemented in upcoming versions.

- [Version 1.0](#section-1)
- [Version 1.1](#section-2)

<br>
<a name="section-1"></a>

#### Version 1.0 - December 06, 2020
First version released.
<br><br>
<a name="section-2"></a>

#### Version 1.1 - December 07, 2020
Improvements.