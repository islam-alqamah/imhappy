<footer class="u-footer d-md-flex align-items-md-center text-center text-md-left text-muted text-muted">
    <p class="h5 mb-0 ml-auto">
        &copy; {{ date('Y') }} <a class="link-muted" href="https://creatydev.com/" target="_blank">{{ __('CreatyDev') }}</a>. {{ __('All Rights Reserved') }}.
    </p>
</footer>