@extends('layouts.account')

@section('content')

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-3 col-xs-12">

            <h6 class="txt-dark">
                {{ __('All Points') }}
            </h6>

        </div>

        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="{{ url('/dashboard') }}">{{ __('Dashboard') }}</a></li>

                <li class="active"><span>{{ __('All Points') }}</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>

    <div class="row">

        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th>{{ __('Branch Name') }}</th>
                                        <th>{{ __('QR-Code') }}</th>
                                        <th>{{ __('Point Name') }}</th>
                                        <th>{{ __('title') }}</th>
                                        <th>{{ __('text') }}</th>
                                        <th>{{ __('Type') }}</th>
                                        <th>{{ __('Responses') }}</th>
                                        <th>{{ __('Options') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($points as $point)
                                        <tr>
                                            <td>
                                                <a href="{{ route('branches.branches.points',['branch'=>$point->branch->id]) }}" target="_blank">
                                                    {{ $point->branch->name }}</a>
                                            </td>
                                            <td>
                                                <a href="{{ url($point->qrcode) }}" target="_blank">
                                                    <img src="{{ url($point->qrcode) }}" width="80"></a>
                                            </td>
                                            <td>
                                                <a href="{{ url('view/point/'.$point->id) }}">{{ $point->name }}</a>
                                            </td>
                                            <td>{{ $point->title }}</td>
                                            <td>{{ $point->text }}</td>
                                            <td>{{ $point->type=='survey'?'Touchless':'QR-Code' }}</td>
                                            <td>
                                                <?php

                                                if($point->type == 'survey'){
                                                    $questions = $point->form->questions;
                                                    $answers = 0;
                                                    foreach ($questions as $question){
                                                        $answers += \App\Models\QuestionAnswer::where('question_id',$question->id)->get()->count();
                                                    }
                                                    echo $answers/$questions->count();                                                }else{
                                                ?>
                                                {{ (isset($point->form->responses))?$point->form->responses->count():0 }}
                                                <?php
                                                }
                                                ?>
                                            </td>                                            <td>
                                                <a data-toggle="tooltip" title="{{ __('Live Editor')}}" href="{{ route('branches.points.editor',['point'=>$point->id,'branch'=>$point->branch->id]) }}" class="btn btn-icon-anim btn-circle btn-sm btn-success">
                                                    <i class="fa fa-file"></i>
                                                </a>
                                                <a data-toggle="tooltip" title="{{ __('View Responses')}}" href="{{ route('branches.points.responses',['point'=>$point->id]) }}" class="btn btn-icon-anim btn-circle btn-sm btn-primary">
                                                    <i class="fa fa-list"></i>
                                                </a>
                                                <a data-toggle="tooltip" title="{{ __('Delete !!')}}" href="{{ route('branches.points.delete',['point'=>$point->id]) }}"
                                                   onclick="return confirm('{{ __('Are you sure ?') }}')" class="btn btn-sm btn-icon-anim btn-circle btn-danger">
                                                    <i class="icon-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection