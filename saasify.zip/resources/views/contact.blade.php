<x-guest-layout>
    @livewire('contact-form')
      <!-- Stories Section -->
</x-guest-layout>