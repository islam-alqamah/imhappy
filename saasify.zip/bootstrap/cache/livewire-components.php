<?php return array (
  'backup' => 'App\\Http\\Livewire\\Backup',
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'maintenance-mode' => 'App\\Http\\Livewire\\MaintenanceMode',
  'payments' => 'App\\Http\\Livewire\\Payments',
  'plan-list' => 'App\\Http\\Livewire\\PlanList',
  'preferences' => 'App\\Http\\Livewire\\Preferences',
  'show-users' => 'App\\Http\\Livewire\\ShowUsers',
  'swap-plan' => 'App\\Http\\Livewire\\SwapPlan',
);