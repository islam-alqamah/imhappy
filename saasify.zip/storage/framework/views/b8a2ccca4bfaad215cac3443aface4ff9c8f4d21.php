<?php $__env->startSection('content'); ?>
    <div class="row heading-bg">

    <h5 class="mt-10"><?php echo e($team->settings->company_name); ?></h5>
    <!-- Row -->
    </div>
    <!-- /Row -->
    <div class="row">
        <div class="col-md-12">

        </div>
    </div>
    <!-- Row -->
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="panel panel-default card-view panel-refresh">
                <div class="refresh-container">
                    <div class="la-anim-1"></div>
                </div>
                <div class="panel-heading">
                    <div class="pull-left">
                        <form id="filtering" class="form-inline" action="<?php echo e(route('reports')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <select name="city_id" id="city"  class="form-control">
                                    <option value="all">-- <?php echo e(__('All Cities')); ?> --</option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(isset($request->city_id) && $request->city_id == $city->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="branch_id" id="branch" onchange="form.submit()" class="form-control">
                                    <option value="all">-- <?php echo e(__('All Branches')); ?> --</option>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(isset($request->branch_id) && $request->branch_id == $branch->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="point_id" id="point" onchange="form.submit()" class="form-control">
                                    <option value="all">-- <?php echo e(__('All Points')); ?> --</option>
                                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(isset($request->point_id) && $request->point_id == $point->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($point->id); ?>"><?php echo e($point->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input class="form-control input-daterange-datepicker"  type="text" name="date_range"
                                       value="<?php echo e(isset($request->date_range) ?$request->date_range:'01-01-2021 - 12-31-2021'); ?>">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Filter')); ?></button>
                            </div>
                        </form>
                    </div>
                    <div class="pull-right">
                        <a href="#" class="pull-left inline-block refresh mr-15">
                            <i class="zmdi zmdi-replay"></i>
                        </a>
                        <a href="#" class="pull-left inline-block full-screen mr-15">
                            <i class="zmdi zmdi-fullscreen"></i>
                        </a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover display  pb-30" >
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('Date / Time')); ?></th>
                                        <th><?php echo e(__('City')); ?></th>
                                        <th><?php echo e(__('Branch')); ?></th>
                                        <th><?php echo e(__('Point')); ?></th>
                                        <th><?php echo e(__('IP Address')); ?></th>
                                        <th><?php echo e(__('Email')); ?></th>
                                        <th><?php echo e(__('Phone')); ?></th>
                                        <th><?php echo e(__('Feedback')); ?></th>
                                        <th><?php echo e(__('Rate')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($response->created_at); ?></td>
                                            <td><?php echo e($response->branch->city->name); ?></td>
                                            <td><?php echo e($response->branch->name); ?></td>
                                            <td><?php echo e($response->form->point->name); ?></td>
                                            <td><?php echo e($response->user_ip); ?></td>
                                            <td><?php echo e($response->email); ?></td>
                                            <td><?php echo e($response->phone); ?></td>
                                            <td><?php echo e($response->feedback); ?></td>
                                            <td>
                                                <p align="center">
                                                    <img alt="<?php echo e($response->rate); ?>" width="30"
                                                         src="<?php echo e(url('assets/img/').'/'.$response->rate.'.png'); ?>">
                                                </p>
                                                <p align="center"><?php echo e($response->rate); ?></p>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /Row -->
    <!-- Row -->

    <!-- Row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap Daterangepicker CSS -->
    <link href="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables/media/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap Daterangepicker CSS -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


    <!-- Data table JavaScript -->
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/pdfmake/build/vfs_fonts.js"></script>

    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(url('assets/dist/')); ?>/js/export-table-data.js"></script>


    <script type="text/javascript" src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/moment/min/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
    <!-- Bootstrap Daterangepicker JavaScript -->
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Form Picker Init JavaScript -->
    <!-- ChartJS JavaScript -->
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/chart.js/Chart.min.js"></script>
<script>

    $(document).on('change','#city',function () {
        $('#branch').val('all')
        $('#point').val('all')
        $('#filtering').submit();
    });
    $(document).on('change','#branch',function () {
        $('#point').val('all');
        $('#filtering').submit();
    });

    $('.input-daterange-datepicker').daterangepicker({
        format:'DD-MM-YYYY',
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/reports.blade.php ENDPATH**/ ?>