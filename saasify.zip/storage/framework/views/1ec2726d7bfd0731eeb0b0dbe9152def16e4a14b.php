<?php $__env->startSection('content'); ?>
       <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <form action="<?php echo e(route('feedback.submit',['form'=>$point->form->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <p align="center">
                                <img width="150" height="90" src="<?php echo e(url($point->team->settings->logo)); ?>">
                            </p>
                            <p align="center"><?php echo e($point->branch->name); ?> - <?php echo e($point->name); ?></p>

                            <h3 class="mt-15 text-center"><?php echo e($point->title); ?></h3>

                            <h5 class="mt-10" id="rate-heading"><?php echo e($point->form->rate_label); ?></h5>

                            <div class="btn-group mt-15 mr-10">

                                <button type="button" data-target="#excellent" class="btn btn-rate btn-default btn-outline btn-rounded">
                                    <img src="<?php echo e(url('assets/img/excellent.png')); ?>" width="40">
                                    <input type="radio" required class="rate-radio" name="rate" style="display: none"  value="excellent"  >
                                </button>

                                <button type="button" data-target="#average" class="btn btn-rate btn-default btn-outline btn-rounded">
                                    <img src="<?php echo e(url('assets/img/average.png')); ?>" width="40">
                                    <input type="radio"  class="rate-radio" name="rate" style="display: none" value="average" >
                                </button>

                                <button type="button" data-target="#verypoor" class="btn btn-rate btn-default btn-rounded btn-outline">
                                    <img src="<?php echo e(url('assets/img/verypoor.png')); ?>" width="40">
                                    <input type="radio"  class="rate-radio" name="rate" style="display: none" value="verypoor" >
                                </button>

                            </div>
                            <?php
                                $Fields = (isset($point->form->fields))?json_decode($point->form->fields,true):['email'=>'yes','feedback'=>'no'];
                            ?>
                            <?php if(array_key_exists('email',$Fields)): ?>
                            <div id="email-field" class="input-group mt-10">
                                <div class="input-group-addon"><i class="icon-envelope-open"></i></div>
                                <input type="email" <?php if($Fields['email']=='yes'): ?> required <?php endif; ?> name="email" class="form-control" id="email" placeholder="<?php echo e(__('Email Address')); ?>">
                            </div>
                            <?php endif; ?>
                            <?php if(array_key_exists('phone',$Fields)): ?>
                            <div id="phone-field" class="input-group mt-10">
                                <div class="input-group-addon"><i class="icon-phone"></i></div>
                                <input type="text" <?php if($Fields['phone']=='yes'): ?> required <?php endif; ?> name="phone" class="form-control" id="" placeholder="<?php echo e(__('Phone Number')); ?>">
                            </div>
                            <?php endif; ?>
                            <?php if(array_key_exists('feedback',$Fields)): ?>
                            <div  id="feedback-field" class=" mt-10">
                                <textarea class="form-control  mt-10" <?php if($Fields['feedback']=='yes'): ?> required <?php endif; ?> name="feedback" rows="5" placeholder="<?php echo e(__('Your Feedback')); ?>"></textarea>
                            </div>
                            <?php endif; ?>
                            <button id="submit-btn" class="btn btn-lg btn-rounded btn-primary btn-block mt-10 theme-color"><?php echo e($point->form->submit_text); ?></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/logos/logo-h.png')); ?>" width="110"></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
   <style>
       .active-btn{
           background-color: <?php echo e($point->form->theme_color); ?> !important;
       }
       .theme-color{
           background-color: <?php echo e($point->form->theme_color); ?> !important;
       }
   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/switchery/dist/switchery.min.js"></script>

    <script>
        $('.btn-rate').on('click',function () {
            $('.rate-radio').removeAttr('checked');
            $('.btn-rate').removeClass('active-btn');
            $('.btn-rate').addClass('btn-outline');
            var btn_id = $(this).data('target');
            $(this).addClass('active-btn');
            $(this).removeClass('btn-outline');
            $(this).children('input[type="radio"]').prop('checked', true);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.point-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/feedback.blade.php ENDPATH**/ ?>