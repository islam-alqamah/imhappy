<div class="d-flex justify-content-center mb-4">
    
</div>
<?php /**PATH C:\xampp\htdocs\saasify\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>