<?php $__env->startSection('content'); ?>
    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark"><?php echo e(__('Plans')); ?></h5>
        </div>

        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                <li class="active"><span><?php echo e(__('Plans')); ?></span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="row">
                <!-- item -->
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 text-center mb-30">
                        <div class="panel panel-pricing card-view mb-0">
                            <div class="panel-heading">
                                <i class="ti-wallet"></i>
                                <h6><?php echo e($plan->title); ?></h6>
                                <span class="panel-price"><?php echo e($plan->price); ?><span class="pricing-dolor">SAR</span></span>
                            </div>
                            <div class="panel-body text-center pl-0 pr-0">
                                <hr class="mb-30">
                                <ul class="list-group mb-0 text-center">
                                    <li class="list-group-item"><i class="fa fa-check"></i> <?php echo e($plan->branches); ?> Branches</li>
                                    <li><hr class="mt-5 mb-5"></li>
                                    <li class="list-group-item"><i class="fa fa-check"></i> <?php echo e($plan->points); ?> Points</li>
                                    <li><hr class="mt-5 mb-5"></li>
                                    <li class="list-group-item"><i class="fa fa-check"></i>
                                        <?php echo e(implode(",",json_decode($plan->channels))); ?>

                                    </li>
                                    <li><hr class="mt-5 mb-5"></li>
                                    <li class="list-group-item"><i class="fa fa-check"></i> 27/7 support</li>
                                </ul>
                            </div>
                            <div class="panel-footer pb-35">
                                <form method="post" action="<?php echo e(route('account.new.subscription')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="currency" value="SAR">
                                    <input type="hidden" name="amount" value="<?php echo e($plan->price); ?>">
                                    <input type="hidden" name="order_id" value="9988">
                                    <button class="btn btn-primary btn-outline fancy-button btn-0 btn-rounded btn-lg" type="submit">subscribe now</button>
                                </form>                </div>
                        </div>
                    </div>
                    <!-- /item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/account/plan.blade.php ENDPATH**/ ?>