<?php $__env->startSection('content'); ?>
    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark"><?php echo e(__('Payments History')); ?></h5>
        </div>

        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                <li class="active"><span><?php echo e(__('Payments History')); ?></span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default card-view panel-refresh">
                <div class="refresh-container">
                    <div class="la-anim-1"></div>
                </div>
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark"><?php echo e(__('Payments')); ?></h6>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body row pa-0">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover display  pb-30" >
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('Invoice No.')); ?></th>
                                        <th><?php echo e(__('Subscription Date')); ?></th>
                                        <th><?php echo e(__('Transaction ID')); ?></th>
                                        <th><?php echo e(__('Plan')); ?></th>
                                        <th><?php echo e(__('Pricing Model')); ?></th>
                                        <th><?php echo e(__('Amount')); ?></th>
                                        <th><?php echo e(__('Starts at')); ?></th>
                                        <th><?php echo e(__('Ends at')); ?></th>
                                        <th><?php echo e(__('Status')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="<?php echo e(url('account/payments/').'/'.$payment->id); ?>">#021<?php echo e($payment->id); ?></a></td>
                                            <td><?php echo e($payment->created_at->format('Y-m-d')); ?></td>
                                            <td><?php echo e($payment->tranid); ?></td>
                                            <td><?php echo e($payment->plan->title); ?></td>
                                            <td><?php echo e($payment->plan->interval); ?></td>
                                            <td><?php echo number_format($payment->amount,2); ?></td>
                                            <td>
                                                <?php if($payment->subscribe): ?>
                                                    <?php echo e($payment->subscribe->starts_at); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($payment->subscribe): ?>
                                                   <?php echo e($payment->subscribe->ends_at); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($payment->status == 'success'): ?>
                                                    <span style="background: #2DAD00" class="badge badge-success"><?php echo e(__('Success')); ?></span>
                                                <?php else: ?>
                                                    <span style="background: #f52828" class="badge badge-danger"><?php echo e(__('Failed')); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/account/payment-history.blade.php ENDPATH**/ ?>