<?php if($errors->any()): ?>
    <div <?php echo $attributes->merge(['class' => 'alert alert-danger']); ?> role="alert">
        <div class="text-danger"><?php echo e(__('Whoops! Something went wrong.')); ?></div>

        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\saasify\resources\views/vendor/jetstream/components/validation-errors.blade.php ENDPATH**/ ?>