<?php $__env->startSection('content'); ?>
       <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-default">
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                            <p align="center">
                                <img width="150" height="90" src="<?php echo e(url($point->team->settings->logo)); ?>">
                            </p>
                            <p align="center"><?php echo e($point->branch->name); ?> - <?php echo e($point->name); ?></p>

                            <h5 class="mt-10 text-center" id="rate-heading"><?php echo e($point->text); ?></h5>

                    </div>
                </div>
            </div>
            <div class="pull-left">
            <a class="btn btn-circle btn-sm btn-primary" target="_blank" href="<?php echo e($point->team->settings->facebook); ?>">
                <i class="fa fa-facebook font-18"></i> </a>
            <a class="btn btn-circle btn-sm btn-danger" target="_blank" href="<?php echo e($point->team->settings->youtube); ?>">
                <i class="fa fa-youtube font-18"></i> </a>
            <a class="btn btn-circle btn-sm btn-default" target="_blank" href="<?php echo e($point->team->settings->instagram); ?>">
                <i class="fa fa-instagram font-18"></i> </a>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/logos/logo-h.png')); ?>" width="110"></a>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
   <style>
       .active-btn{
           background-color: <?php echo e($point->form->theme_color); ?> !important;
       }
       .theme-color{
           background-color: <?php echo e($point->form->theme_color); ?> !important;
       }
   </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/switchery/dist/switchery.min.js"></script>

    <script>
        $('.btn-rate').on('click',function () {
            $('.rate-radio').removeAttr('checked');
            $('.btn-rate').removeClass('active-btn');
            $('.btn-rate').addClass('btn-outline');
            var btn_id = $(this).data('target');
            $(this).addClass('active-btn');
            $(this).removeClass('btn-outline');
            $(this).children('input[type="radio"]').prop('checked', true);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.point-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/thanks.blade.php ENDPATH**/ ?>