<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\saasify\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>