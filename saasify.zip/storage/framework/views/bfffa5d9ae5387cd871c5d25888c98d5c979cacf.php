<?php $__env->startSection('content'); ?>


    <div class="row">

        <div class="col-md-12 mt-20">
            <div class="panel panel-default card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark"> <?php echo e(__('All Points ')); ?></h6>
                    </div>
                    <div class="pull-right">

                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                                <table id="example" class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('Branch Name')); ?></th>
                                        <th><?php echo e(__('QR-Code')); ?></th>
                                        <th><?php echo e(__('Point Name')); ?></th>
                                        <th><?php echo e(__('title')); ?></th>
                                        <th><?php echo e(__('text')); ?></th>
                                        <th><?php echo e(__('Type')); ?></th>
                                        <th><?php echo e(__('Responses')); ?></th>
                                        <th><?php echo e(__('Options')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($point->branch): ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('branches.branches.points',['branch'=>$point->branch->id])); ?>" target="_blank">
                                                    <?php echo e($point->branch->name); ?></a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url($point->qrcode)); ?>" target="_blank">
                                                    <img src="<?php echo e(url($point->qrcode)); ?>" width="80"></a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('view/point/'.$point->id)); ?>"><?php echo e($point->name); ?></a>
                                            </td>
                                            <td><?php echo e($point->title); ?></td>
                                            <td><?php echo e($point->text); ?></td>
                                            <td><?php echo e($point->type=='survey'?'Touchless':'QR-Code'); ?></td>
                                            <td>
                                                <?php

                                                if($point->type == 'survey'){
                                                    $questions = $point->form->questions;
                                                    $answers = 0;
                                                    foreach ($questions as $question){
                                                        $answers += \App\Models\QuestionAnswer::where('question_id',$question->id)->get()->count();
                                                    }
                                                    if($questions->count()){
                                                        echo $answers/$questions->count();
                                                    }else{
                                                        echo 0;
                                                    }
                                                }else{
                                                ?>
                                                <?php echo e((isset($point->form->responses))?$point->form->responses->count():0); ?>

                                                <?php
                                                }
                                                ?>
                                            </td>
                                            <td >
                                                <div class="btn-group">
                                                    <div class="dropdown">
                                                        <button aria-expanded="false" data-toggle="dropdown" style="border:none" class="btn btn-default btn-circle btn-outline dropdown-toggle" type="button">
                                                            <i class="fa fa-bars"></i> <span class="caret"></span></button>
                                                        <ul role="menu" class="dropdown-menu">
                                                            <li>
                                                                <a href="<?php echo e(route('branches.points.editor',['point'=>$point->id,'branch'=>$point->branch->id])); ?>">
                                                                    <i class="fa fa-edit"></i> <?php echo e(__('Editor')); ?>

                                                                </a>
                                                            </li>
                                                            <li class="divider"></li>
                                                            <li><a href="<?php echo e(route('branches.points.responses',['point'=>$point->id])); ?>">
                                                                    <i class="fa fa-eye"></i>    <?php echo e(__('View Responses')); ?>    </a></li>
                                                            <li class="divider"></li>
                                                            <li><a class="del-btn" data-toggle="modal" data-target="#delete_<?php echo e($point->id); ?>" href="#">
                                                                    <i class="icon-trash"></i> <?php echo e(__('Delete')); ?>    </a></li>

                                                        </ul>
                                                    </div>
                                                </div>

                                                <div id="delete_<?php echo e($point->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                <h5 class="modal-title" id="myModalLabel"><?php echo e(__('Delete Point')); ?> - <?php echo e($point->name); ?></h5>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group row">
                                                                    <div class="col-md-12">
                                                                        <p align="center"> By deleting this point all saved data will be removed.</p>
                                                                        <p align="center" class="msg"> Please export before deleting to prevent any loss of data.</p>
                                                                        <p align="center" class="msg-confirmation" style="display: none;"> Are you sure you want to delete ? </p>
                                                                        <br/>
                                                                        <p class="options-btn" align="center">
                                                                            <a target="_blank" href="<?php echo e(url('reports')); ?>"
                                                                               class="btn btn-primary btn-outline fancy-button btn-0" style="margin-right: 5px">
                                                                                <i class="fa fa-download"></i>   <?php echo e(__('Export')); ?></a>
                                                                            <a href="#" class="btn btn-danger btn-outline fancy-button btn-0 btn-delete" >
                                                                                <i class="icon-trash"></i> <?php echo e(__('Delete')); ?></a>
                                                                        </p>
                                                                        <p align="center" class="confirmation-btn" style="display: none">
                                                                            <a href="#"  data-dismiss="modal" aria-hidden="true" class="btn btn-primary btn-outline fancy-button btn-0 " >
                                                                                <i class="icon-ban"></i> <?php echo e(__('No')); ?></a>
                                                                            <a href="<?php echo e(route('branches.points.delete',['point'=>$point->id])); ?>"
                                                                               class="btn btn-danger btn-outline fancy-button btn-0 " >
                                                                                <i class="icon-trash"></i> <?php echo e(__('Yes')); ?></a>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Data table JavaScript -->
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/pdfmake/build/vfs_fonts.js"></script>

    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(url('assets/dist/')); ?>/js/export-table-data.js"></script>
    <script>
        $(document).on('change','#city',function () {
            if($(this).val() == 0){
                $('#new-city').show();
            }else{
                $('#new-city').hide();
            }
        });
        $(document).on('click','.btn-delete',function () {
            $('.options-btn').hide();
            $('.msg').hide();
            $('.confirmation-btn').show();
            $('.msg-confirmation').show();
        });
        $(document).on('click','.del-btn',function (){
            $('.options-btn').show();
            $('.msg').show();
            $('.confirmation-btn').hide();
            $('.msg-confirmation').hide();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/account/allpoints.blade.php ENDPATH**/ ?>