<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title><?php echo e(config('app.name', 'Laravel')); ?> <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="ImHappy"/>

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Data table CSS -->
    <link href="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables/media/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

    <link href="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css" rel="stylesheet" type="text/css">

<?php echo $__env->yieldContent('styles'); ?>
    <!-- Custom CSS -->
    <link href="<?php echo e(url('assets/dist/')); ?>/css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<!-- Preloader -->
<div class="preloader-it">
    <div class="la-anim-1"></div>
</div>
<!-- /Preloader -->
<div class="wrapper" style="background: #fff;width: 100%;min-height: 100vh; padding: 80px 25px">


    <!-- Main Content -->
    <div  >
        <div class="container-fluid ">

            <?php echo $__env->yieldContent('content'); ?>

        </div>


    </div>
    <!-- /Main Content -->


</div>
<!-- /#wrapper -->

<!-- JavaScript -->

<!-- jQuery -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jquery/dist/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- Data table JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo e(url('assets/dist/')); ?>/js/jquery.slimscroll.js"></script>

<!-- Progressbar Animation JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jquery.counterup/jquery.counterup.min.js"></script>

<!-- Fancy Dropdown JS -->
<script src="<?php echo e(url('assets/dist/')); ?>/js/dropdown-bootstrap-extended.js"></script>

<!-- Sparkline JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/jquery.sparkline/dist/jquery.sparkline.min.js"></script>

<!-- Owl JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

<!-- Switchery JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/switchery/dist/switchery.min.js"></script>

<!-- EChartJS JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/echarts/dist/echarts-en.min.js"></script>
<script src="<?php echo e(url('assets/dist/vendors')); ?>/echarts-liquidfill.min.js"></script>

<!-- Toast JavaScript -->
<script src="<?php echo e(url('assets/dist/vendors')); ?>/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js"></script>

<?php echo $__env->yieldContent('scripts'); ?>
<!-- Init JavaScript -->
<script src="<?php echo e(url('assets/dist/')); ?>/js/init.js"></script>
<script src="<?php echo e(url('assets/dist/')); ?>/js/dashboard-data.js"></script>



<?php if(session()->has('status')): ?>
    <script>
        $(window).load(function(){

        		$.toast({
        			heading: '<?php echo e(__('System Message !')); ?>',
        			text: '<?php echo e(__( session()->get('msg') )); ?>',
        			position: 'top-center',
        			loaderBg:'#f8b32d',
        			icon: '<?php echo session()->get('status'); ?>',
        			hideAfter: 4500,
        			stack: 6
        		});

        });
    </script>
<?php endif; ?>
</body>


</html>

<?php /**PATH C:\xampp\htdocs\saasify\resources\views/layouts/point-layout.blade.php ENDPATH**/ ?>