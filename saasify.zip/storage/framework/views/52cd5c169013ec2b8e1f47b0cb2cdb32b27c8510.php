<?php $__env->startSection('title', '| Plans'); ?>

<?php $__env->startSection('content'); ?>
<div class="u-body">
    <div class="card">
        <div class="card-header">
            <strong><?php echo e(__('Update Plan')); ?></strong>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.plans.update', $plan->id)); ?>" method="POST" class="form-horizontal offset-sm-2">
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('PUT'); ?>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="hf-name">Plan name</label>
                    <div class="col-md-6">
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo e($plan->title); ?>"
                            placeholder="Enter Plan name..">

                            <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="hf-name"><?php echo e(__('Plan Monthly Price')); ?></label>
                    <div class="col-md-6">
                        <input type="text" id="price" name="price" class="form-control"
                            value="<?php echo e($plan->price); ?>">

                            <?php if($errors->has('price')): ?>
                                <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="hf-name"><?php echo e(__('Plan Annual Price')); ?></label>
                    <div class="col-md-6">
                        <input type="text" id="annual_price" name="annual_price" class="form-control"
                               value="<?php echo e($plan->annual_price); ?>">

                        <?php if($errors->has('annual_price')): ?>
                            <span class="text-danger"><?php echo e($errors->first('annual_price')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="hf-name">Plan Trial</label>
                    <div class="col-md-6">
                        <input type="text" id="trial" name="trial" class="form-control"
                            value="<?php echo e($plan->trial_period_days); ?>">

                            <?php if($errors->has('trial')): ?>
                                <span class="text-danger"><?php echo e($errors->first('trial')); ?></span>
                            <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="branches">Branches Limit</label>
                    <div class="col-md-6">
                        <input type="text" id="branches" name="branches" class="form-control"
                               value="<?php echo e($plan->branches); ?>">

                        <?php if($errors->has('branches')): ?>
                            <span class="text-danger"><?php echo e($errors->first('branches')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="points">Points Limit</label>
                    <div class="col-md-6">
                        <input type="text" id="points" name="points" class="form-control"
                               value="<?php echo e($plan->points); ?>">

                        <?php if($errors->has('points')): ?>
                            <span class="text-danger"><?php echo e($errors->first('points')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-md-3 col-form-label" for="channels">Channels</label>
                    <div class="col-md-6">
                        <label> QR-Code
                            <input type="checkbox" name="channels[]" class="form-control"
                                   value="QR-Code">
                        </label>
                        <label> Touchless
                            <input type="checkbox" name="channels[]" class="form-control"
                                   value="Touchless">
                        </label>
                    </div>
                </div>

                <hr>
                <button type="submit" class="btn btn-secondary"><i class="fa fa-dot-circle-o"></i> <?php echo e(__('Edit plan')); ?></button>
                <button type="reset" class="btn btn-danger"><i class="fa fa-ban"></i> <?php echo e(__('Reset')); ?></button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saasify\resources\views/admin/plans/edit.blade.php ENDPATH**/ ?>